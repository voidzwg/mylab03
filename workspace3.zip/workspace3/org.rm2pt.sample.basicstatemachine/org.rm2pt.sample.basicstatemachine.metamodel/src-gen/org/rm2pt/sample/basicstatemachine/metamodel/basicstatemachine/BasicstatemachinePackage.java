/**
 */
package org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachineFactory
 * @model kind="package"
 * @generated
 */
public interface BasicstatemachinePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "basicstatemachine";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/basicstatemachine";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "basicstatemachine";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	BasicstatemachinePackage eINSTANCE = org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl
			.init();

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl <em>statemachine</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#getstatemachine()
	 * @generated
	 */
	int STATEMACHINE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATEMACHINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>States</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATEMACHINE__STATES = 1;

	/**
	 * The feature id for the '<em><b>Transitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATEMACHINE__TRANSITIONS = 2;

	/**
	 * The number of structural features of the '<em>statemachine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATEMACHINE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>statemachine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATEMACHINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.stateImpl <em>state</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.stateImpl
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#getstate()
	 * @generated
	 */
	int STATE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__NAME = 0;

	/**
	 * The number of structural features of the '<em>state</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>state</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.transitionImpl <em>transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.transitionImpl
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#gettransition()
	 * @generated
	 */
	int TRANSITION = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__TARGET = 2;

	/**
	 * The feature id for the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__EVENT = 3;

	/**
	 * The number of structural features of the '<em>transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.eventImpl <em>event</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.eventImpl
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#getevent()
	 * @generated
	 */
	int EVENT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT__NAME = 0;

	/**
	 * The number of structural features of the '<em>event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>event</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EVENT_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine <em>statemachine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>statemachine</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine
	 * @generated
	 */
	EClass getstatemachine();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getName()
	 * @see #getstatemachine()
	 * @generated
	 */
	EAttribute getstatemachine_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getStates <em>States</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>States</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getStates()
	 * @see #getstatemachine()
	 * @generated
	 */
	EReference getstatemachine_States();

	/**
	 * Returns the meta object for the containment reference list '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getTransitions <em>Transitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transitions</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getTransitions()
	 * @see #getstatemachine()
	 * @generated
	 */
	EReference getstatemachine_Transitions();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.state <em>state</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>state</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.state
	 * @generated
	 */
	EClass getstate();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.state#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.state#getName()
	 * @see #getstate()
	 * @generated
	 */
	EAttribute getstate_Name();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition <em>transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>transition</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition
	 * @generated
	 */
	EClass gettransition();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getName()
	 * @see #gettransition()
	 * @generated
	 */
	EAttribute gettransition_Name();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getSource()
	 * @see #gettransition()
	 * @generated
	 */
	EReference gettransition_Source();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getTarget()
	 * @see #gettransition()
	 * @generated
	 */
	EReference gettransition_Target();

	/**
	 * Returns the meta object for the reference '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getEvent <em>Event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Event</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getEvent()
	 * @see #gettransition()
	 * @generated
	 */
	EReference gettransition_Event();

	/**
	 * Returns the meta object for class '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.event <em>event</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>event</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.event
	 * @generated
	 */
	EClass getevent();

	/**
	 * Returns the meta object for the attribute '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.event#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.event#getName()
	 * @see #getevent()
	 * @generated
	 */
	EAttribute getevent_Name();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	BasicstatemachineFactory getBasicstatemachineFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl <em>statemachine</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#getstatemachine()
		 * @generated
		 */
		EClass STATEMACHINE = eINSTANCE.getstatemachine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATEMACHINE__NAME = eINSTANCE.getstatemachine_Name();

		/**
		 * The meta object literal for the '<em><b>States</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATEMACHINE__STATES = eINSTANCE.getstatemachine_States();

		/**
		 * The meta object literal for the '<em><b>Transitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATEMACHINE__TRANSITIONS = eINSTANCE.getstatemachine_Transitions();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.stateImpl <em>state</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.stateImpl
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#getstate()
		 * @generated
		 */
		EClass STATE = eINSTANCE.getstate();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__NAME = eINSTANCE.getstate_Name();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.transitionImpl <em>transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.transitionImpl
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#gettransition()
		 * @generated
		 */
		EClass TRANSITION = eINSTANCE.gettransition();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__NAME = eINSTANCE.gettransition_Name();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__SOURCE = eINSTANCE.gettransition_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__TARGET = eINSTANCE.gettransition_Target();

		/**
		 * The meta object literal for the '<em><b>Event</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__EVENT = eINSTANCE.gettransition_Event();

		/**
		 * The meta object literal for the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.eventImpl <em>event</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.eventImpl
		 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachinePackageImpl#getevent()
		 * @generated
		 */
		EClass EVENT = eINSTANCE.getevent();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EVENT__NAME = eINSTANCE.getevent_Name();

	}

} //BasicstatemachinePackage
