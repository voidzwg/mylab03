/**
 */
package org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getSource <em>Source</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getTarget <em>Target</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getEvent <em>Event</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#gettransition()
 * @model
 * @generated
 */
public interface transition extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#gettransition_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(state)
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#gettransition_Source()
	 * @model required="true"
	 * @generated
	 */
	state getSource();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(state value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(state)
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#gettransition_Target()
	 * @model required="true"
	 * @generated
	 */
	state getTarget();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(state value);

	/**
	 * Returns the value of the '<em><b>Event</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Event</em>' reference.
	 * @see #setEvent(event)
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#gettransition_Event()
	 * @model
	 * @generated
	 */
	event getEvent();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition#getEvent <em>Event</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Event</em>' reference.
	 * @see #getEvent()
	 * @generated
	 */
	void setEvent(event value);

} // transition
