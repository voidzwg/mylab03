/**
 */
package org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class BasicstatemachineFactoryImpl extends EFactoryImpl implements BasicstatemachineFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static BasicstatemachineFactory init() {
		try {
			BasicstatemachineFactory theBasicstatemachineFactory = (BasicstatemachineFactory) EPackage.Registry.INSTANCE
					.getEFactory(BasicstatemachinePackage.eNS_URI);
			if (theBasicstatemachineFactory != null) {
				return theBasicstatemachineFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new BasicstatemachineFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BasicstatemachineFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case BasicstatemachinePackage.STATEMACHINE:
			return createstatemachine();
		case BasicstatemachinePackage.STATE:
			return createstate();
		case BasicstatemachinePackage.TRANSITION:
			return createtransition();
		case BasicstatemachinePackage.EVENT:
			return createevent();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public statemachine createstatemachine() {
		statemachineImpl statemachine = new statemachineImpl();
		return statemachine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public state createstate() {
		stateImpl state = new stateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public transition createtransition() {
		transitionImpl transition = new transitionImpl();
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public event createevent() {
		eventImpl event = new eventImpl();
		return event;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BasicstatemachinePackage getBasicstatemachinePackage() {
		return (BasicstatemachinePackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static BasicstatemachinePackage getPackage() {
		return BasicstatemachinePackage.eINSTANCE;
	}

} //BasicstatemachineFactoryImpl
