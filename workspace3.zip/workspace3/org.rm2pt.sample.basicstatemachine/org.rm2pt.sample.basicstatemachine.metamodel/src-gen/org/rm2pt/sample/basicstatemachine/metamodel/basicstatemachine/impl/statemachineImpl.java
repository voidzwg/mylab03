/**
 */
package org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage;
import org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.state;
import org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine;
import org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>statemachine</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl#getStates <em>States</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.statemachineImpl#getTransitions <em>Transitions</em>}</li>
 * </ul>
 *
 * @generated
 */
public class statemachineImpl extends MinimalEObjectImpl.Container implements statemachine {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStates() <em>States</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStates()
	 * @generated
	 * @ordered
	 */
	protected EList<state> states;

	/**
	 * The cached value of the '{@link #getTransitions() <em>Transitions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransitions()
	 * @generated
	 * @ordered
	 */
	protected EList<transition> transitions;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected statemachineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BasicstatemachinePackage.Literals.STATEMACHINE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, BasicstatemachinePackage.STATEMACHINE__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<state> getStates() {
		if (states == null) {
			states = new EObjectContainmentEList<state>(state.class, this,
					BasicstatemachinePackage.STATEMACHINE__STATES);
		}
		return states;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<transition> getTransitions() {
		if (transitions == null) {
			transitions = new EObjectContainmentEList<transition>(transition.class, this,
					BasicstatemachinePackage.STATEMACHINE__TRANSITIONS);
		}
		return transitions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case BasicstatemachinePackage.STATEMACHINE__STATES:
			return ((InternalEList<?>) getStates()).basicRemove(otherEnd, msgs);
		case BasicstatemachinePackage.STATEMACHINE__TRANSITIONS:
			return ((InternalEList<?>) getTransitions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case BasicstatemachinePackage.STATEMACHINE__NAME:
			return getName();
		case BasicstatemachinePackage.STATEMACHINE__STATES:
			return getStates();
		case BasicstatemachinePackage.STATEMACHINE__TRANSITIONS:
			return getTransitions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case BasicstatemachinePackage.STATEMACHINE__NAME:
			setName((String) newValue);
			return;
		case BasicstatemachinePackage.STATEMACHINE__STATES:
			getStates().clear();
			getStates().addAll((Collection<? extends state>) newValue);
			return;
		case BasicstatemachinePackage.STATEMACHINE__TRANSITIONS:
			getTransitions().clear();
			getTransitions().addAll((Collection<? extends transition>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case BasicstatemachinePackage.STATEMACHINE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case BasicstatemachinePackage.STATEMACHINE__STATES:
			getStates().clear();
			return;
		case BasicstatemachinePackage.STATEMACHINE__TRANSITIONS:
			getTransitions().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case BasicstatemachinePackage.STATEMACHINE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case BasicstatemachinePackage.STATEMACHINE__STATES:
			return states != null && !states.isEmpty();
		case BasicstatemachinePackage.STATEMACHINE__TRANSITIONS:
			return transitions != null && !transitions.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //statemachineImpl
