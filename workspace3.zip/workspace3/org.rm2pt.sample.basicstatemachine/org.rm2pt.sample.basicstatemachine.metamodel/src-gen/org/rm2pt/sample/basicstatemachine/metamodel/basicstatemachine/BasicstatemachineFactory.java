/**
 */
package org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage
 * @generated
 */
public interface BasicstatemachineFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	BasicstatemachineFactory eINSTANCE = org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.impl.BasicstatemachineFactoryImpl
			.init();

	/**
	 * Returns a new object of class '<em>statemachine</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>statemachine</em>'.
	 * @generated
	 */
	statemachine createstatemachine();

	/**
	 * Returns a new object of class '<em>state</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>state</em>'.
	 * @generated
	 */
	state createstate();

	/**
	 * Returns a new object of class '<em>transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>transition</em>'.
	 * @generated
	 */
	transition createtransition();

	/**
	 * Returns a new object of class '<em>event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>event</em>'.
	 * @generated
	 */
	event createevent();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	BasicstatemachinePackage getBasicstatemachinePackage();

} //BasicstatemachineFactory
