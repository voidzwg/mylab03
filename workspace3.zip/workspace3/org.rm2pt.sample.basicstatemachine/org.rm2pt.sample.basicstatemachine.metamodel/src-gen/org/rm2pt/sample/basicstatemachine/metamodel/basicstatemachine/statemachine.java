/**
 */
package org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>statemachine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getName <em>Name</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getStates <em>States</em>}</li>
 *   <li>{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getTransitions <em>Transitions</em>}</li>
 * </ul>
 *
 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#getstatemachine()
 * @model
 * @generated
 */
public interface statemachine extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#getstatemachine_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.statemachine#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>States</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.state}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>States</em>' containment reference list.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#getstatemachine_States()
	 * @model containment="true"
	 * @generated
	 */
	EList<state> getStates();

	/**
	 * Returns the value of the '<em><b>Transitions</b></em>' containment reference list.
	 * The list contents are of type {@link org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.transition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transitions</em>' containment reference list.
	 * @see org.rm2pt.sample.basicstatemachine.metamodel.basicstatemachine.BasicstatemachinePackage#getstatemachine_Transitions()
	 * @model containment="true"
	 * @generated
	 */
	EList<transition> getTransitions();

} // statemachine
