package org.rm2pt.sample.basicstatemachine.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.rm2pt.sample.basicstatemachine.services.DslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'statemachine'", "'{'", "'}'", "'states'", "','", "'transitions'", "'state'", "'transition'", "'source'", "'target'", "'event'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDsl.g"; }


    	private DslGrammarAccess grammarAccess;

    	public void setGrammarAccess(DslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRulestatemachine"
    // InternalDsl.g:53:1: entryRulestatemachine : rulestatemachine EOF ;
    public final void entryRulestatemachine() throws RecognitionException {
        try {
            // InternalDsl.g:54:1: ( rulestatemachine EOF )
            // InternalDsl.g:55:1: rulestatemachine EOF
            {
             before(grammarAccess.getStatemachineRule()); 
            pushFollow(FOLLOW_1);
            rulestatemachine();

            state._fsp--;

             after(grammarAccess.getStatemachineRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulestatemachine"


    // $ANTLR start "rulestatemachine"
    // InternalDsl.g:62:1: rulestatemachine : ( ( rule__Statemachine__Group__0 ) ) ;
    public final void rulestatemachine() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:66:2: ( ( ( rule__Statemachine__Group__0 ) ) )
            // InternalDsl.g:67:2: ( ( rule__Statemachine__Group__0 ) )
            {
            // InternalDsl.g:67:2: ( ( rule__Statemachine__Group__0 ) )
            // InternalDsl.g:68:3: ( rule__Statemachine__Group__0 )
            {
             before(grammarAccess.getStatemachineAccess().getGroup()); 
            // InternalDsl.g:69:3: ( rule__Statemachine__Group__0 )
            // InternalDsl.g:69:4: rule__Statemachine__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStatemachineAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulestatemachine"


    // $ANTLR start "entryRuleEString"
    // InternalDsl.g:78:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalDsl.g:79:1: ( ruleEString EOF )
            // InternalDsl.g:80:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalDsl.g:87:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:91:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalDsl.g:92:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalDsl.g:92:2: ( ( rule__EString__Alternatives ) )
            // InternalDsl.g:93:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalDsl.g:94:3: ( rule__EString__Alternatives )
            // InternalDsl.g:94:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRulestate"
    // InternalDsl.g:103:1: entryRulestate : rulestate EOF ;
    public final void entryRulestate() throws RecognitionException {
        try {
            // InternalDsl.g:104:1: ( rulestate EOF )
            // InternalDsl.g:105:1: rulestate EOF
            {
             before(grammarAccess.getStateRule()); 
            pushFollow(FOLLOW_1);
            rulestate();

            state._fsp--;

             after(grammarAccess.getStateRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulestate"


    // $ANTLR start "rulestate"
    // InternalDsl.g:112:1: rulestate : ( ( rule__State__Group__0 ) ) ;
    public final void rulestate() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:116:2: ( ( ( rule__State__Group__0 ) ) )
            // InternalDsl.g:117:2: ( ( rule__State__Group__0 ) )
            {
            // InternalDsl.g:117:2: ( ( rule__State__Group__0 ) )
            // InternalDsl.g:118:3: ( rule__State__Group__0 )
            {
             before(grammarAccess.getStateAccess().getGroup()); 
            // InternalDsl.g:119:3: ( rule__State__Group__0 )
            // InternalDsl.g:119:4: rule__State__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulestate"


    // $ANTLR start "entryRuletransition"
    // InternalDsl.g:128:1: entryRuletransition : ruletransition EOF ;
    public final void entryRuletransition() throws RecognitionException {
        try {
            // InternalDsl.g:129:1: ( ruletransition EOF )
            // InternalDsl.g:130:1: ruletransition EOF
            {
             before(grammarAccess.getTransitionRule()); 
            pushFollow(FOLLOW_1);
            ruletransition();

            state._fsp--;

             after(grammarAccess.getTransitionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuletransition"


    // $ANTLR start "ruletransition"
    // InternalDsl.g:137:1: ruletransition : ( ( rule__Transition__Group__0 ) ) ;
    public final void ruletransition() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:141:2: ( ( ( rule__Transition__Group__0 ) ) )
            // InternalDsl.g:142:2: ( ( rule__Transition__Group__0 ) )
            {
            // InternalDsl.g:142:2: ( ( rule__Transition__Group__0 ) )
            // InternalDsl.g:143:3: ( rule__Transition__Group__0 )
            {
             before(grammarAccess.getTransitionAccess().getGroup()); 
            // InternalDsl.g:144:3: ( rule__Transition__Group__0 )
            // InternalDsl.g:144:4: rule__Transition__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruletransition"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalDsl.g:152:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:156:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_STRING) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_ID) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalDsl.g:157:2: ( RULE_STRING )
                    {
                    // InternalDsl.g:157:2: ( RULE_STRING )
                    // InternalDsl.g:158:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalDsl.g:163:2: ( RULE_ID )
                    {
                    // InternalDsl.g:163:2: ( RULE_ID )
                    // InternalDsl.g:164:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__Statemachine__Group__0"
    // InternalDsl.g:173:1: rule__Statemachine__Group__0 : rule__Statemachine__Group__0__Impl rule__Statemachine__Group__1 ;
    public final void rule__Statemachine__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:177:1: ( rule__Statemachine__Group__0__Impl rule__Statemachine__Group__1 )
            // InternalDsl.g:178:2: rule__Statemachine__Group__0__Impl rule__Statemachine__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Statemachine__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__0"


    // $ANTLR start "rule__Statemachine__Group__0__Impl"
    // InternalDsl.g:185:1: rule__Statemachine__Group__0__Impl : ( () ) ;
    public final void rule__Statemachine__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:189:1: ( ( () ) )
            // InternalDsl.g:190:1: ( () )
            {
            // InternalDsl.g:190:1: ( () )
            // InternalDsl.g:191:2: ()
            {
             before(grammarAccess.getStatemachineAccess().getStatemachineAction_0()); 
            // InternalDsl.g:192:2: ()
            // InternalDsl.g:192:3: 
            {
            }

             after(grammarAccess.getStatemachineAccess().getStatemachineAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__0__Impl"


    // $ANTLR start "rule__Statemachine__Group__1"
    // InternalDsl.g:200:1: rule__Statemachine__Group__1 : rule__Statemachine__Group__1__Impl rule__Statemachine__Group__2 ;
    public final void rule__Statemachine__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:204:1: ( rule__Statemachine__Group__1__Impl rule__Statemachine__Group__2 )
            // InternalDsl.g:205:2: rule__Statemachine__Group__1__Impl rule__Statemachine__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Statemachine__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__1"


    // $ANTLR start "rule__Statemachine__Group__1__Impl"
    // InternalDsl.g:212:1: rule__Statemachine__Group__1__Impl : ( 'statemachine' ) ;
    public final void rule__Statemachine__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:216:1: ( ( 'statemachine' ) )
            // InternalDsl.g:217:1: ( 'statemachine' )
            {
            // InternalDsl.g:217:1: ( 'statemachine' )
            // InternalDsl.g:218:2: 'statemachine'
            {
             before(grammarAccess.getStatemachineAccess().getStatemachineKeyword_1()); 
            match(input,11,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getStatemachineKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__1__Impl"


    // $ANTLR start "rule__Statemachine__Group__2"
    // InternalDsl.g:227:1: rule__Statemachine__Group__2 : rule__Statemachine__Group__2__Impl rule__Statemachine__Group__3 ;
    public final void rule__Statemachine__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:231:1: ( rule__Statemachine__Group__2__Impl rule__Statemachine__Group__3 )
            // InternalDsl.g:232:2: rule__Statemachine__Group__2__Impl rule__Statemachine__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Statemachine__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__2"


    // $ANTLR start "rule__Statemachine__Group__2__Impl"
    // InternalDsl.g:239:1: rule__Statemachine__Group__2__Impl : ( ( rule__Statemachine__NameAssignment_2 ) ) ;
    public final void rule__Statemachine__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:243:1: ( ( ( rule__Statemachine__NameAssignment_2 ) ) )
            // InternalDsl.g:244:1: ( ( rule__Statemachine__NameAssignment_2 ) )
            {
            // InternalDsl.g:244:1: ( ( rule__Statemachine__NameAssignment_2 ) )
            // InternalDsl.g:245:2: ( rule__Statemachine__NameAssignment_2 )
            {
             before(grammarAccess.getStatemachineAccess().getNameAssignment_2()); 
            // InternalDsl.g:246:2: ( rule__Statemachine__NameAssignment_2 )
            // InternalDsl.g:246:3: rule__Statemachine__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStatemachineAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__2__Impl"


    // $ANTLR start "rule__Statemachine__Group__3"
    // InternalDsl.g:254:1: rule__Statemachine__Group__3 : rule__Statemachine__Group__3__Impl rule__Statemachine__Group__4 ;
    public final void rule__Statemachine__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:258:1: ( rule__Statemachine__Group__3__Impl rule__Statemachine__Group__4 )
            // InternalDsl.g:259:2: rule__Statemachine__Group__3__Impl rule__Statemachine__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__Statemachine__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__3"


    // $ANTLR start "rule__Statemachine__Group__3__Impl"
    // InternalDsl.g:266:1: rule__Statemachine__Group__3__Impl : ( '{' ) ;
    public final void rule__Statemachine__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:270:1: ( ( '{' ) )
            // InternalDsl.g:271:1: ( '{' )
            {
            // InternalDsl.g:271:1: ( '{' )
            // InternalDsl.g:272:2: '{'
            {
             before(grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__3__Impl"


    // $ANTLR start "rule__Statemachine__Group__4"
    // InternalDsl.g:281:1: rule__Statemachine__Group__4 : rule__Statemachine__Group__4__Impl rule__Statemachine__Group__5 ;
    public final void rule__Statemachine__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:285:1: ( rule__Statemachine__Group__4__Impl rule__Statemachine__Group__5 )
            // InternalDsl.g:286:2: rule__Statemachine__Group__4__Impl rule__Statemachine__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__Statemachine__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__4"


    // $ANTLR start "rule__Statemachine__Group__4__Impl"
    // InternalDsl.g:293:1: rule__Statemachine__Group__4__Impl : ( ( rule__Statemachine__Group_4__0 )? ) ;
    public final void rule__Statemachine__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:297:1: ( ( ( rule__Statemachine__Group_4__0 )? ) )
            // InternalDsl.g:298:1: ( ( rule__Statemachine__Group_4__0 )? )
            {
            // InternalDsl.g:298:1: ( ( rule__Statemachine__Group_4__0 )? )
            // InternalDsl.g:299:2: ( rule__Statemachine__Group_4__0 )?
            {
             before(grammarAccess.getStatemachineAccess().getGroup_4()); 
            // InternalDsl.g:300:2: ( rule__Statemachine__Group_4__0 )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalDsl.g:300:3: rule__Statemachine__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Statemachine__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStatemachineAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__4__Impl"


    // $ANTLR start "rule__Statemachine__Group__5"
    // InternalDsl.g:308:1: rule__Statemachine__Group__5 : rule__Statemachine__Group__5__Impl rule__Statemachine__Group__6 ;
    public final void rule__Statemachine__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:312:1: ( rule__Statemachine__Group__5__Impl rule__Statemachine__Group__6 )
            // InternalDsl.g:313:2: rule__Statemachine__Group__5__Impl rule__Statemachine__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__Statemachine__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__5"


    // $ANTLR start "rule__Statemachine__Group__5__Impl"
    // InternalDsl.g:320:1: rule__Statemachine__Group__5__Impl : ( ( rule__Statemachine__Group_5__0 )? ) ;
    public final void rule__Statemachine__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:324:1: ( ( ( rule__Statemachine__Group_5__0 )? ) )
            // InternalDsl.g:325:1: ( ( rule__Statemachine__Group_5__0 )? )
            {
            // InternalDsl.g:325:1: ( ( rule__Statemachine__Group_5__0 )? )
            // InternalDsl.g:326:2: ( rule__Statemachine__Group_5__0 )?
            {
             before(grammarAccess.getStatemachineAccess().getGroup_5()); 
            // InternalDsl.g:327:2: ( rule__Statemachine__Group_5__0 )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==16) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalDsl.g:327:3: rule__Statemachine__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Statemachine__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getStatemachineAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__5__Impl"


    // $ANTLR start "rule__Statemachine__Group__6"
    // InternalDsl.g:335:1: rule__Statemachine__Group__6 : rule__Statemachine__Group__6__Impl ;
    public final void rule__Statemachine__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:339:1: ( rule__Statemachine__Group__6__Impl )
            // InternalDsl.g:340:2: rule__Statemachine__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__6"


    // $ANTLR start "rule__Statemachine__Group__6__Impl"
    // InternalDsl.g:346:1: rule__Statemachine__Group__6__Impl : ( '}' ) ;
    public final void rule__Statemachine__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:350:1: ( ( '}' ) )
            // InternalDsl.g:351:1: ( '}' )
            {
            // InternalDsl.g:351:1: ( '}' )
            // InternalDsl.g:352:2: '}'
            {
             before(grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_6()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group__6__Impl"


    // $ANTLR start "rule__Statemachine__Group_4__0"
    // InternalDsl.g:362:1: rule__Statemachine__Group_4__0 : rule__Statemachine__Group_4__0__Impl rule__Statemachine__Group_4__1 ;
    public final void rule__Statemachine__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:366:1: ( rule__Statemachine__Group_4__0__Impl rule__Statemachine__Group_4__1 )
            // InternalDsl.g:367:2: rule__Statemachine__Group_4__0__Impl rule__Statemachine__Group_4__1
            {
            pushFollow(FOLLOW_5);
            rule__Statemachine__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__0"


    // $ANTLR start "rule__Statemachine__Group_4__0__Impl"
    // InternalDsl.g:374:1: rule__Statemachine__Group_4__0__Impl : ( 'states' ) ;
    public final void rule__Statemachine__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:378:1: ( ( 'states' ) )
            // InternalDsl.g:379:1: ( 'states' )
            {
            // InternalDsl.g:379:1: ( 'states' )
            // InternalDsl.g:380:2: 'states'
            {
             before(grammarAccess.getStatemachineAccess().getStatesKeyword_4_0()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getStatesKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__0__Impl"


    // $ANTLR start "rule__Statemachine__Group_4__1"
    // InternalDsl.g:389:1: rule__Statemachine__Group_4__1 : rule__Statemachine__Group_4__1__Impl rule__Statemachine__Group_4__2 ;
    public final void rule__Statemachine__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:393:1: ( rule__Statemachine__Group_4__1__Impl rule__Statemachine__Group_4__2 )
            // InternalDsl.g:394:2: rule__Statemachine__Group_4__1__Impl rule__Statemachine__Group_4__2
            {
            pushFollow(FOLLOW_7);
            rule__Statemachine__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__1"


    // $ANTLR start "rule__Statemachine__Group_4__1__Impl"
    // InternalDsl.g:401:1: rule__Statemachine__Group_4__1__Impl : ( '{' ) ;
    public final void rule__Statemachine__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:405:1: ( ( '{' ) )
            // InternalDsl.g:406:1: ( '{' )
            {
            // InternalDsl.g:406:1: ( '{' )
            // InternalDsl.g:407:2: '{'
            {
             before(grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_4_1()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__1__Impl"


    // $ANTLR start "rule__Statemachine__Group_4__2"
    // InternalDsl.g:416:1: rule__Statemachine__Group_4__2 : rule__Statemachine__Group_4__2__Impl rule__Statemachine__Group_4__3 ;
    public final void rule__Statemachine__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:420:1: ( rule__Statemachine__Group_4__2__Impl rule__Statemachine__Group_4__3 )
            // InternalDsl.g:421:2: rule__Statemachine__Group_4__2__Impl rule__Statemachine__Group_4__3
            {
            pushFollow(FOLLOW_8);
            rule__Statemachine__Group_4__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__2"


    // $ANTLR start "rule__Statemachine__Group_4__2__Impl"
    // InternalDsl.g:428:1: rule__Statemachine__Group_4__2__Impl : ( ( rule__Statemachine__StatesAssignment_4_2 ) ) ;
    public final void rule__Statemachine__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:432:1: ( ( ( rule__Statemachine__StatesAssignment_4_2 ) ) )
            // InternalDsl.g:433:1: ( ( rule__Statemachine__StatesAssignment_4_2 ) )
            {
            // InternalDsl.g:433:1: ( ( rule__Statemachine__StatesAssignment_4_2 ) )
            // InternalDsl.g:434:2: ( rule__Statemachine__StatesAssignment_4_2 )
            {
             before(grammarAccess.getStatemachineAccess().getStatesAssignment_4_2()); 
            // InternalDsl.g:435:2: ( rule__Statemachine__StatesAssignment_4_2 )
            // InternalDsl.g:435:3: rule__Statemachine__StatesAssignment_4_2
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__StatesAssignment_4_2();

            state._fsp--;


            }

             after(grammarAccess.getStatemachineAccess().getStatesAssignment_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__2__Impl"


    // $ANTLR start "rule__Statemachine__Group_4__3"
    // InternalDsl.g:443:1: rule__Statemachine__Group_4__3 : rule__Statemachine__Group_4__3__Impl rule__Statemachine__Group_4__4 ;
    public final void rule__Statemachine__Group_4__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:447:1: ( rule__Statemachine__Group_4__3__Impl rule__Statemachine__Group_4__4 )
            // InternalDsl.g:448:2: rule__Statemachine__Group_4__3__Impl rule__Statemachine__Group_4__4
            {
            pushFollow(FOLLOW_8);
            rule__Statemachine__Group_4__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__3"


    // $ANTLR start "rule__Statemachine__Group_4__3__Impl"
    // InternalDsl.g:455:1: rule__Statemachine__Group_4__3__Impl : ( ( rule__Statemachine__Group_4_3__0 )* ) ;
    public final void rule__Statemachine__Group_4__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:459:1: ( ( ( rule__Statemachine__Group_4_3__0 )* ) )
            // InternalDsl.g:460:1: ( ( rule__Statemachine__Group_4_3__0 )* )
            {
            // InternalDsl.g:460:1: ( ( rule__Statemachine__Group_4_3__0 )* )
            // InternalDsl.g:461:2: ( rule__Statemachine__Group_4_3__0 )*
            {
             before(grammarAccess.getStatemachineAccess().getGroup_4_3()); 
            // InternalDsl.g:462:2: ( rule__Statemachine__Group_4_3__0 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==15) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalDsl.g:462:3: rule__Statemachine__Group_4_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Statemachine__Group_4_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getStatemachineAccess().getGroup_4_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__3__Impl"


    // $ANTLR start "rule__Statemachine__Group_4__4"
    // InternalDsl.g:470:1: rule__Statemachine__Group_4__4 : rule__Statemachine__Group_4__4__Impl ;
    public final void rule__Statemachine__Group_4__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:474:1: ( rule__Statemachine__Group_4__4__Impl )
            // InternalDsl.g:475:2: rule__Statemachine__Group_4__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__4"


    // $ANTLR start "rule__Statemachine__Group_4__4__Impl"
    // InternalDsl.g:481:1: rule__Statemachine__Group_4__4__Impl : ( '}' ) ;
    public final void rule__Statemachine__Group_4__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:485:1: ( ( '}' ) )
            // InternalDsl.g:486:1: ( '}' )
            {
            // InternalDsl.g:486:1: ( '}' )
            // InternalDsl.g:487:2: '}'
            {
             before(grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_4_4()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_4_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4__4__Impl"


    // $ANTLR start "rule__Statemachine__Group_4_3__0"
    // InternalDsl.g:497:1: rule__Statemachine__Group_4_3__0 : rule__Statemachine__Group_4_3__0__Impl rule__Statemachine__Group_4_3__1 ;
    public final void rule__Statemachine__Group_4_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:501:1: ( rule__Statemachine__Group_4_3__0__Impl rule__Statemachine__Group_4_3__1 )
            // InternalDsl.g:502:2: rule__Statemachine__Group_4_3__0__Impl rule__Statemachine__Group_4_3__1
            {
            pushFollow(FOLLOW_7);
            rule__Statemachine__Group_4_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4_3__0"


    // $ANTLR start "rule__Statemachine__Group_4_3__0__Impl"
    // InternalDsl.g:509:1: rule__Statemachine__Group_4_3__0__Impl : ( ',' ) ;
    public final void rule__Statemachine__Group_4_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:513:1: ( ( ',' ) )
            // InternalDsl.g:514:1: ( ',' )
            {
            // InternalDsl.g:514:1: ( ',' )
            // InternalDsl.g:515:2: ','
            {
             before(grammarAccess.getStatemachineAccess().getCommaKeyword_4_3_0()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getCommaKeyword_4_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4_3__0__Impl"


    // $ANTLR start "rule__Statemachine__Group_4_3__1"
    // InternalDsl.g:524:1: rule__Statemachine__Group_4_3__1 : rule__Statemachine__Group_4_3__1__Impl ;
    public final void rule__Statemachine__Group_4_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:528:1: ( rule__Statemachine__Group_4_3__1__Impl )
            // InternalDsl.g:529:2: rule__Statemachine__Group_4_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_4_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4_3__1"


    // $ANTLR start "rule__Statemachine__Group_4_3__1__Impl"
    // InternalDsl.g:535:1: rule__Statemachine__Group_4_3__1__Impl : ( ( rule__Statemachine__StatesAssignment_4_3_1 ) ) ;
    public final void rule__Statemachine__Group_4_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:539:1: ( ( ( rule__Statemachine__StatesAssignment_4_3_1 ) ) )
            // InternalDsl.g:540:1: ( ( rule__Statemachine__StatesAssignment_4_3_1 ) )
            {
            // InternalDsl.g:540:1: ( ( rule__Statemachine__StatesAssignment_4_3_1 ) )
            // InternalDsl.g:541:2: ( rule__Statemachine__StatesAssignment_4_3_1 )
            {
             before(grammarAccess.getStatemachineAccess().getStatesAssignment_4_3_1()); 
            // InternalDsl.g:542:2: ( rule__Statemachine__StatesAssignment_4_3_1 )
            // InternalDsl.g:542:3: rule__Statemachine__StatesAssignment_4_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__StatesAssignment_4_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStatemachineAccess().getStatesAssignment_4_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_4_3__1__Impl"


    // $ANTLR start "rule__Statemachine__Group_5__0"
    // InternalDsl.g:551:1: rule__Statemachine__Group_5__0 : rule__Statemachine__Group_5__0__Impl rule__Statemachine__Group_5__1 ;
    public final void rule__Statemachine__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:555:1: ( rule__Statemachine__Group_5__0__Impl rule__Statemachine__Group_5__1 )
            // InternalDsl.g:556:2: rule__Statemachine__Group_5__0__Impl rule__Statemachine__Group_5__1
            {
            pushFollow(FOLLOW_5);
            rule__Statemachine__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__0"


    // $ANTLR start "rule__Statemachine__Group_5__0__Impl"
    // InternalDsl.g:563:1: rule__Statemachine__Group_5__0__Impl : ( 'transitions' ) ;
    public final void rule__Statemachine__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:567:1: ( ( 'transitions' ) )
            // InternalDsl.g:568:1: ( 'transitions' )
            {
            // InternalDsl.g:568:1: ( 'transitions' )
            // InternalDsl.g:569:2: 'transitions'
            {
             before(grammarAccess.getStatemachineAccess().getTransitionsKeyword_5_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getTransitionsKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__0__Impl"


    // $ANTLR start "rule__Statemachine__Group_5__1"
    // InternalDsl.g:578:1: rule__Statemachine__Group_5__1 : rule__Statemachine__Group_5__1__Impl rule__Statemachine__Group_5__2 ;
    public final void rule__Statemachine__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:582:1: ( rule__Statemachine__Group_5__1__Impl rule__Statemachine__Group_5__2 )
            // InternalDsl.g:583:2: rule__Statemachine__Group_5__1__Impl rule__Statemachine__Group_5__2
            {
            pushFollow(FOLLOW_10);
            rule__Statemachine__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__1"


    // $ANTLR start "rule__Statemachine__Group_5__1__Impl"
    // InternalDsl.g:590:1: rule__Statemachine__Group_5__1__Impl : ( '{' ) ;
    public final void rule__Statemachine__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:594:1: ( ( '{' ) )
            // InternalDsl.g:595:1: ( '{' )
            {
            // InternalDsl.g:595:1: ( '{' )
            // InternalDsl.g:596:2: '{'
            {
             before(grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__1__Impl"


    // $ANTLR start "rule__Statemachine__Group_5__2"
    // InternalDsl.g:605:1: rule__Statemachine__Group_5__2 : rule__Statemachine__Group_5__2__Impl rule__Statemachine__Group_5__3 ;
    public final void rule__Statemachine__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:609:1: ( rule__Statemachine__Group_5__2__Impl rule__Statemachine__Group_5__3 )
            // InternalDsl.g:610:2: rule__Statemachine__Group_5__2__Impl rule__Statemachine__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__Statemachine__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__2"


    // $ANTLR start "rule__Statemachine__Group_5__2__Impl"
    // InternalDsl.g:617:1: rule__Statemachine__Group_5__2__Impl : ( ( rule__Statemachine__TransitionsAssignment_5_2 ) ) ;
    public final void rule__Statemachine__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:621:1: ( ( ( rule__Statemachine__TransitionsAssignment_5_2 ) ) )
            // InternalDsl.g:622:1: ( ( rule__Statemachine__TransitionsAssignment_5_2 ) )
            {
            // InternalDsl.g:622:1: ( ( rule__Statemachine__TransitionsAssignment_5_2 ) )
            // InternalDsl.g:623:2: ( rule__Statemachine__TransitionsAssignment_5_2 )
            {
             before(grammarAccess.getStatemachineAccess().getTransitionsAssignment_5_2()); 
            // InternalDsl.g:624:2: ( rule__Statemachine__TransitionsAssignment_5_2 )
            // InternalDsl.g:624:3: rule__Statemachine__TransitionsAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__TransitionsAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getStatemachineAccess().getTransitionsAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__2__Impl"


    // $ANTLR start "rule__Statemachine__Group_5__3"
    // InternalDsl.g:632:1: rule__Statemachine__Group_5__3 : rule__Statemachine__Group_5__3__Impl rule__Statemachine__Group_5__4 ;
    public final void rule__Statemachine__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:636:1: ( rule__Statemachine__Group_5__3__Impl rule__Statemachine__Group_5__4 )
            // InternalDsl.g:637:2: rule__Statemachine__Group_5__3__Impl rule__Statemachine__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__Statemachine__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__3"


    // $ANTLR start "rule__Statemachine__Group_5__3__Impl"
    // InternalDsl.g:644:1: rule__Statemachine__Group_5__3__Impl : ( ( rule__Statemachine__Group_5_3__0 )* ) ;
    public final void rule__Statemachine__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:648:1: ( ( ( rule__Statemachine__Group_5_3__0 )* ) )
            // InternalDsl.g:649:1: ( ( rule__Statemachine__Group_5_3__0 )* )
            {
            // InternalDsl.g:649:1: ( ( rule__Statemachine__Group_5_3__0 )* )
            // InternalDsl.g:650:2: ( rule__Statemachine__Group_5_3__0 )*
            {
             before(grammarAccess.getStatemachineAccess().getGroup_5_3()); 
            // InternalDsl.g:651:2: ( rule__Statemachine__Group_5_3__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==15) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalDsl.g:651:3: rule__Statemachine__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Statemachine__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getStatemachineAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__3__Impl"


    // $ANTLR start "rule__Statemachine__Group_5__4"
    // InternalDsl.g:659:1: rule__Statemachine__Group_5__4 : rule__Statemachine__Group_5__4__Impl ;
    public final void rule__Statemachine__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:663:1: ( rule__Statemachine__Group_5__4__Impl )
            // InternalDsl.g:664:2: rule__Statemachine__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__4"


    // $ANTLR start "rule__Statemachine__Group_5__4__Impl"
    // InternalDsl.g:670:1: rule__Statemachine__Group_5__4__Impl : ( '}' ) ;
    public final void rule__Statemachine__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:674:1: ( ( '}' ) )
            // InternalDsl.g:675:1: ( '}' )
            {
            // InternalDsl.g:675:1: ( '}' )
            // InternalDsl.g:676:2: '}'
            {
             before(grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5__4__Impl"


    // $ANTLR start "rule__Statemachine__Group_5_3__0"
    // InternalDsl.g:686:1: rule__Statemachine__Group_5_3__0 : rule__Statemachine__Group_5_3__0__Impl rule__Statemachine__Group_5_3__1 ;
    public final void rule__Statemachine__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:690:1: ( rule__Statemachine__Group_5_3__0__Impl rule__Statemachine__Group_5_3__1 )
            // InternalDsl.g:691:2: rule__Statemachine__Group_5_3__0__Impl rule__Statemachine__Group_5_3__1
            {
            pushFollow(FOLLOW_10);
            rule__Statemachine__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5_3__0"


    // $ANTLR start "rule__Statemachine__Group_5_3__0__Impl"
    // InternalDsl.g:698:1: rule__Statemachine__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__Statemachine__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:702:1: ( ( ',' ) )
            // InternalDsl.g:703:1: ( ',' )
            {
            // InternalDsl.g:703:1: ( ',' )
            // InternalDsl.g:704:2: ','
            {
             before(grammarAccess.getStatemachineAccess().getCommaKeyword_5_3_0()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getStatemachineAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5_3__0__Impl"


    // $ANTLR start "rule__Statemachine__Group_5_3__1"
    // InternalDsl.g:713:1: rule__Statemachine__Group_5_3__1 : rule__Statemachine__Group_5_3__1__Impl ;
    public final void rule__Statemachine__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:717:1: ( rule__Statemachine__Group_5_3__1__Impl )
            // InternalDsl.g:718:2: rule__Statemachine__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5_3__1"


    // $ANTLR start "rule__Statemachine__Group_5_3__1__Impl"
    // InternalDsl.g:724:1: rule__Statemachine__Group_5_3__1__Impl : ( ( rule__Statemachine__TransitionsAssignment_5_3_1 ) ) ;
    public final void rule__Statemachine__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:728:1: ( ( ( rule__Statemachine__TransitionsAssignment_5_3_1 ) ) )
            // InternalDsl.g:729:1: ( ( rule__Statemachine__TransitionsAssignment_5_3_1 ) )
            {
            // InternalDsl.g:729:1: ( ( rule__Statemachine__TransitionsAssignment_5_3_1 ) )
            // InternalDsl.g:730:2: ( rule__Statemachine__TransitionsAssignment_5_3_1 )
            {
             before(grammarAccess.getStatemachineAccess().getTransitionsAssignment_5_3_1()); 
            // InternalDsl.g:731:2: ( rule__Statemachine__TransitionsAssignment_5_3_1 )
            // InternalDsl.g:731:3: rule__Statemachine__TransitionsAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Statemachine__TransitionsAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getStatemachineAccess().getTransitionsAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__Group_5_3__1__Impl"


    // $ANTLR start "rule__State__Group__0"
    // InternalDsl.g:740:1: rule__State__Group__0 : rule__State__Group__0__Impl rule__State__Group__1 ;
    public final void rule__State__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:744:1: ( rule__State__Group__0__Impl rule__State__Group__1 )
            // InternalDsl.g:745:2: rule__State__Group__0__Impl rule__State__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__State__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0"


    // $ANTLR start "rule__State__Group__0__Impl"
    // InternalDsl.g:752:1: rule__State__Group__0__Impl : ( () ) ;
    public final void rule__State__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:756:1: ( ( () ) )
            // InternalDsl.g:757:1: ( () )
            {
            // InternalDsl.g:757:1: ( () )
            // InternalDsl.g:758:2: ()
            {
             before(grammarAccess.getStateAccess().getStateAction_0()); 
            // InternalDsl.g:759:2: ()
            // InternalDsl.g:759:3: 
            {
            }

             after(grammarAccess.getStateAccess().getStateAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__0__Impl"


    // $ANTLR start "rule__State__Group__1"
    // InternalDsl.g:767:1: rule__State__Group__1 : rule__State__Group__1__Impl rule__State__Group__2 ;
    public final void rule__State__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:771:1: ( rule__State__Group__1__Impl rule__State__Group__2 )
            // InternalDsl.g:772:2: rule__State__Group__1__Impl rule__State__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__State__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__State__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1"


    // $ANTLR start "rule__State__Group__1__Impl"
    // InternalDsl.g:779:1: rule__State__Group__1__Impl : ( 'state' ) ;
    public final void rule__State__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:783:1: ( ( 'state' ) )
            // InternalDsl.g:784:1: ( 'state' )
            {
            // InternalDsl.g:784:1: ( 'state' )
            // InternalDsl.g:785:2: 'state'
            {
             before(grammarAccess.getStateAccess().getStateKeyword_1()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getStateAccess().getStateKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__1__Impl"


    // $ANTLR start "rule__State__Group__2"
    // InternalDsl.g:794:1: rule__State__Group__2 : rule__State__Group__2__Impl ;
    public final void rule__State__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:798:1: ( rule__State__Group__2__Impl )
            // InternalDsl.g:799:2: rule__State__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__State__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2"


    // $ANTLR start "rule__State__Group__2__Impl"
    // InternalDsl.g:805:1: rule__State__Group__2__Impl : ( ( rule__State__NameAssignment_2 ) ) ;
    public final void rule__State__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:809:1: ( ( ( rule__State__NameAssignment_2 ) ) )
            // InternalDsl.g:810:1: ( ( rule__State__NameAssignment_2 ) )
            {
            // InternalDsl.g:810:1: ( ( rule__State__NameAssignment_2 ) )
            // InternalDsl.g:811:2: ( rule__State__NameAssignment_2 )
            {
             before(grammarAccess.getStateAccess().getNameAssignment_2()); 
            // InternalDsl.g:812:2: ( rule__State__NameAssignment_2 )
            // InternalDsl.g:812:3: rule__State__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__State__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getStateAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__0"
    // InternalDsl.g:821:1: rule__Transition__Group__0 : rule__Transition__Group__0__Impl rule__Transition__Group__1 ;
    public final void rule__Transition__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:825:1: ( rule__Transition__Group__0__Impl rule__Transition__Group__1 )
            // InternalDsl.g:826:2: rule__Transition__Group__0__Impl rule__Transition__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0"


    // $ANTLR start "rule__Transition__Group__0__Impl"
    // InternalDsl.g:833:1: rule__Transition__Group__0__Impl : ( 'transition' ) ;
    public final void rule__Transition__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:837:1: ( ( 'transition' ) )
            // InternalDsl.g:838:1: ( 'transition' )
            {
            // InternalDsl.g:838:1: ( 'transition' )
            // InternalDsl.g:839:2: 'transition'
            {
             before(grammarAccess.getTransitionAccess().getTransitionKeyword_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTransitionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__0__Impl"


    // $ANTLR start "rule__Transition__Group__1"
    // InternalDsl.g:848:1: rule__Transition__Group__1 : rule__Transition__Group__1__Impl rule__Transition__Group__2 ;
    public final void rule__Transition__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:852:1: ( rule__Transition__Group__1__Impl rule__Transition__Group__2 )
            // InternalDsl.g:853:2: rule__Transition__Group__1__Impl rule__Transition__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Transition__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1"


    // $ANTLR start "rule__Transition__Group__1__Impl"
    // InternalDsl.g:860:1: rule__Transition__Group__1__Impl : ( ( rule__Transition__NameAssignment_1 ) ) ;
    public final void rule__Transition__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:864:1: ( ( ( rule__Transition__NameAssignment_1 ) ) )
            // InternalDsl.g:865:1: ( ( rule__Transition__NameAssignment_1 ) )
            {
            // InternalDsl.g:865:1: ( ( rule__Transition__NameAssignment_1 ) )
            // InternalDsl.g:866:2: ( rule__Transition__NameAssignment_1 )
            {
             before(grammarAccess.getTransitionAccess().getNameAssignment_1()); 
            // InternalDsl.g:867:2: ( rule__Transition__NameAssignment_1 )
            // InternalDsl.g:867:3: rule__Transition__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__1__Impl"


    // $ANTLR start "rule__Transition__Group__2"
    // InternalDsl.g:875:1: rule__Transition__Group__2 : rule__Transition__Group__2__Impl rule__Transition__Group__3 ;
    public final void rule__Transition__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:879:1: ( rule__Transition__Group__2__Impl rule__Transition__Group__3 )
            // InternalDsl.g:880:2: rule__Transition__Group__2__Impl rule__Transition__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__Transition__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2"


    // $ANTLR start "rule__Transition__Group__2__Impl"
    // InternalDsl.g:887:1: rule__Transition__Group__2__Impl : ( '{' ) ;
    public final void rule__Transition__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:891:1: ( ( '{' ) )
            // InternalDsl.g:892:1: ( '{' )
            {
            // InternalDsl.g:892:1: ( '{' )
            // InternalDsl.g:893:2: '{'
            {
             before(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,12,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__2__Impl"


    // $ANTLR start "rule__Transition__Group__3"
    // InternalDsl.g:902:1: rule__Transition__Group__3 : rule__Transition__Group__3__Impl rule__Transition__Group__4 ;
    public final void rule__Transition__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:906:1: ( rule__Transition__Group__3__Impl rule__Transition__Group__4 )
            // InternalDsl.g:907:2: rule__Transition__Group__3__Impl rule__Transition__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3"


    // $ANTLR start "rule__Transition__Group__3__Impl"
    // InternalDsl.g:914:1: rule__Transition__Group__3__Impl : ( 'source' ) ;
    public final void rule__Transition__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:918:1: ( ( 'source' ) )
            // InternalDsl.g:919:1: ( 'source' )
            {
            // InternalDsl.g:919:1: ( 'source' )
            // InternalDsl.g:920:2: 'source'
            {
             before(grammarAccess.getTransitionAccess().getSourceKeyword_3()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getSourceKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__3__Impl"


    // $ANTLR start "rule__Transition__Group__4"
    // InternalDsl.g:929:1: rule__Transition__Group__4 : rule__Transition__Group__4__Impl rule__Transition__Group__5 ;
    public final void rule__Transition__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:933:1: ( rule__Transition__Group__4__Impl rule__Transition__Group__5 )
            // InternalDsl.g:934:2: rule__Transition__Group__4__Impl rule__Transition__Group__5
            {
            pushFollow(FOLLOW_12);
            rule__Transition__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4"


    // $ANTLR start "rule__Transition__Group__4__Impl"
    // InternalDsl.g:941:1: rule__Transition__Group__4__Impl : ( ( rule__Transition__SourceAssignment_4 ) ) ;
    public final void rule__Transition__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:945:1: ( ( ( rule__Transition__SourceAssignment_4 ) ) )
            // InternalDsl.g:946:1: ( ( rule__Transition__SourceAssignment_4 ) )
            {
            // InternalDsl.g:946:1: ( ( rule__Transition__SourceAssignment_4 ) )
            // InternalDsl.g:947:2: ( rule__Transition__SourceAssignment_4 )
            {
             before(grammarAccess.getTransitionAccess().getSourceAssignment_4()); 
            // InternalDsl.g:948:2: ( rule__Transition__SourceAssignment_4 )
            // InternalDsl.g:948:3: rule__Transition__SourceAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Transition__SourceAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getSourceAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__4__Impl"


    // $ANTLR start "rule__Transition__Group__5"
    // InternalDsl.g:956:1: rule__Transition__Group__5 : rule__Transition__Group__5__Impl rule__Transition__Group__6 ;
    public final void rule__Transition__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:960:1: ( rule__Transition__Group__5__Impl rule__Transition__Group__6 )
            // InternalDsl.g:961:2: rule__Transition__Group__5__Impl rule__Transition__Group__6
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5"


    // $ANTLR start "rule__Transition__Group__5__Impl"
    // InternalDsl.g:968:1: rule__Transition__Group__5__Impl : ( 'target' ) ;
    public final void rule__Transition__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:972:1: ( ( 'target' ) )
            // InternalDsl.g:973:1: ( 'target' )
            {
            // InternalDsl.g:973:1: ( 'target' )
            // InternalDsl.g:974:2: 'target'
            {
             before(grammarAccess.getTransitionAccess().getTargetKeyword_5()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getTargetKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__5__Impl"


    // $ANTLR start "rule__Transition__Group__6"
    // InternalDsl.g:983:1: rule__Transition__Group__6 : rule__Transition__Group__6__Impl rule__Transition__Group__7 ;
    public final void rule__Transition__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:987:1: ( rule__Transition__Group__6__Impl rule__Transition__Group__7 )
            // InternalDsl.g:988:2: rule__Transition__Group__6__Impl rule__Transition__Group__7
            {
            pushFollow(FOLLOW_13);
            rule__Transition__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6"


    // $ANTLR start "rule__Transition__Group__6__Impl"
    // InternalDsl.g:995:1: rule__Transition__Group__6__Impl : ( ( rule__Transition__TargetAssignment_6 ) ) ;
    public final void rule__Transition__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:999:1: ( ( ( rule__Transition__TargetAssignment_6 ) ) )
            // InternalDsl.g:1000:1: ( ( rule__Transition__TargetAssignment_6 ) )
            {
            // InternalDsl.g:1000:1: ( ( rule__Transition__TargetAssignment_6 ) )
            // InternalDsl.g:1001:2: ( rule__Transition__TargetAssignment_6 )
            {
             before(grammarAccess.getTransitionAccess().getTargetAssignment_6()); 
            // InternalDsl.g:1002:2: ( rule__Transition__TargetAssignment_6 )
            // InternalDsl.g:1002:3: rule__Transition__TargetAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__Transition__TargetAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getTargetAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__6__Impl"


    // $ANTLR start "rule__Transition__Group__7"
    // InternalDsl.g:1010:1: rule__Transition__Group__7 : rule__Transition__Group__7__Impl rule__Transition__Group__8 ;
    public final void rule__Transition__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1014:1: ( rule__Transition__Group__7__Impl rule__Transition__Group__8 )
            // InternalDsl.g:1015:2: rule__Transition__Group__7__Impl rule__Transition__Group__8
            {
            pushFollow(FOLLOW_13);
            rule__Transition__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7"


    // $ANTLR start "rule__Transition__Group__7__Impl"
    // InternalDsl.g:1022:1: rule__Transition__Group__7__Impl : ( ( rule__Transition__Group_7__0 )? ) ;
    public final void rule__Transition__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1026:1: ( ( ( rule__Transition__Group_7__0 )? ) )
            // InternalDsl.g:1027:1: ( ( rule__Transition__Group_7__0 )? )
            {
            // InternalDsl.g:1027:1: ( ( rule__Transition__Group_7__0 )? )
            // InternalDsl.g:1028:2: ( rule__Transition__Group_7__0 )?
            {
             before(grammarAccess.getTransitionAccess().getGroup_7()); 
            // InternalDsl.g:1029:2: ( rule__Transition__Group_7__0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==21) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalDsl.g:1029:3: rule__Transition__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Transition__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getTransitionAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__7__Impl"


    // $ANTLR start "rule__Transition__Group__8"
    // InternalDsl.g:1037:1: rule__Transition__Group__8 : rule__Transition__Group__8__Impl ;
    public final void rule__Transition__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1041:1: ( rule__Transition__Group__8__Impl )
            // InternalDsl.g:1042:2: rule__Transition__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__8"


    // $ANTLR start "rule__Transition__Group__8__Impl"
    // InternalDsl.g:1048:1: rule__Transition__Group__8__Impl : ( '}' ) ;
    public final void rule__Transition__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1052:1: ( ( '}' ) )
            // InternalDsl.g:1053:1: ( '}' )
            {
            // InternalDsl.g:1053:1: ( '}' )
            // InternalDsl.g:1054:2: '}'
            {
             before(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_8()); 
            match(input,13,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group__8__Impl"


    // $ANTLR start "rule__Transition__Group_7__0"
    // InternalDsl.g:1064:1: rule__Transition__Group_7__0 : rule__Transition__Group_7__0__Impl rule__Transition__Group_7__1 ;
    public final void rule__Transition__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1068:1: ( rule__Transition__Group_7__0__Impl rule__Transition__Group_7__1 )
            // InternalDsl.g:1069:2: rule__Transition__Group_7__0__Impl rule__Transition__Group_7__1
            {
            pushFollow(FOLLOW_4);
            rule__Transition__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Transition__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_7__0"


    // $ANTLR start "rule__Transition__Group_7__0__Impl"
    // InternalDsl.g:1076:1: rule__Transition__Group_7__0__Impl : ( 'event' ) ;
    public final void rule__Transition__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1080:1: ( ( 'event' ) )
            // InternalDsl.g:1081:1: ( 'event' )
            {
            // InternalDsl.g:1081:1: ( 'event' )
            // InternalDsl.g:1082:2: 'event'
            {
             before(grammarAccess.getTransitionAccess().getEventKeyword_7_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getTransitionAccess().getEventKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_7__0__Impl"


    // $ANTLR start "rule__Transition__Group_7__1"
    // InternalDsl.g:1091:1: rule__Transition__Group_7__1 : rule__Transition__Group_7__1__Impl ;
    public final void rule__Transition__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1095:1: ( rule__Transition__Group_7__1__Impl )
            // InternalDsl.g:1096:2: rule__Transition__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Transition__Group_7__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_7__1"


    // $ANTLR start "rule__Transition__Group_7__1__Impl"
    // InternalDsl.g:1102:1: rule__Transition__Group_7__1__Impl : ( ( rule__Transition__EventAssignment_7_1 ) ) ;
    public final void rule__Transition__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1106:1: ( ( ( rule__Transition__EventAssignment_7_1 ) ) )
            // InternalDsl.g:1107:1: ( ( rule__Transition__EventAssignment_7_1 ) )
            {
            // InternalDsl.g:1107:1: ( ( rule__Transition__EventAssignment_7_1 ) )
            // InternalDsl.g:1108:2: ( rule__Transition__EventAssignment_7_1 )
            {
             before(grammarAccess.getTransitionAccess().getEventAssignment_7_1()); 
            // InternalDsl.g:1109:2: ( rule__Transition__EventAssignment_7_1 )
            // InternalDsl.g:1109:3: rule__Transition__EventAssignment_7_1
            {
            pushFollow(FOLLOW_2);
            rule__Transition__EventAssignment_7_1();

            state._fsp--;


            }

             after(grammarAccess.getTransitionAccess().getEventAssignment_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__Group_7__1__Impl"


    // $ANTLR start "rule__Statemachine__NameAssignment_2"
    // InternalDsl.g:1118:1: rule__Statemachine__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Statemachine__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1122:1: ( ( ruleEString ) )
            // InternalDsl.g:1123:2: ( ruleEString )
            {
            // InternalDsl.g:1123:2: ( ruleEString )
            // InternalDsl.g:1124:3: ruleEString
            {
             before(grammarAccess.getStatemachineAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStatemachineAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__NameAssignment_2"


    // $ANTLR start "rule__Statemachine__StatesAssignment_4_2"
    // InternalDsl.g:1133:1: rule__Statemachine__StatesAssignment_4_2 : ( rulestate ) ;
    public final void rule__Statemachine__StatesAssignment_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1137:1: ( ( rulestate ) )
            // InternalDsl.g:1138:2: ( rulestate )
            {
            // InternalDsl.g:1138:2: ( rulestate )
            // InternalDsl.g:1139:3: rulestate
            {
             before(grammarAccess.getStatemachineAccess().getStatesStateParserRuleCall_4_2_0()); 
            pushFollow(FOLLOW_2);
            rulestate();

            state._fsp--;

             after(grammarAccess.getStatemachineAccess().getStatesStateParserRuleCall_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__StatesAssignment_4_2"


    // $ANTLR start "rule__Statemachine__StatesAssignment_4_3_1"
    // InternalDsl.g:1148:1: rule__Statemachine__StatesAssignment_4_3_1 : ( rulestate ) ;
    public final void rule__Statemachine__StatesAssignment_4_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1152:1: ( ( rulestate ) )
            // InternalDsl.g:1153:2: ( rulestate )
            {
            // InternalDsl.g:1153:2: ( rulestate )
            // InternalDsl.g:1154:3: rulestate
            {
             before(grammarAccess.getStatemachineAccess().getStatesStateParserRuleCall_4_3_1_0()); 
            pushFollow(FOLLOW_2);
            rulestate();

            state._fsp--;

             after(grammarAccess.getStatemachineAccess().getStatesStateParserRuleCall_4_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__StatesAssignment_4_3_1"


    // $ANTLR start "rule__Statemachine__TransitionsAssignment_5_2"
    // InternalDsl.g:1163:1: rule__Statemachine__TransitionsAssignment_5_2 : ( ruletransition ) ;
    public final void rule__Statemachine__TransitionsAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1167:1: ( ( ruletransition ) )
            // InternalDsl.g:1168:2: ( ruletransition )
            {
            // InternalDsl.g:1168:2: ( ruletransition )
            // InternalDsl.g:1169:3: ruletransition
            {
             before(grammarAccess.getStatemachineAccess().getTransitionsTransitionParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruletransition();

            state._fsp--;

             after(grammarAccess.getStatemachineAccess().getTransitionsTransitionParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__TransitionsAssignment_5_2"


    // $ANTLR start "rule__Statemachine__TransitionsAssignment_5_3_1"
    // InternalDsl.g:1178:1: rule__Statemachine__TransitionsAssignment_5_3_1 : ( ruletransition ) ;
    public final void rule__Statemachine__TransitionsAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1182:1: ( ( ruletransition ) )
            // InternalDsl.g:1183:2: ( ruletransition )
            {
            // InternalDsl.g:1183:2: ( ruletransition )
            // InternalDsl.g:1184:3: ruletransition
            {
             before(grammarAccess.getStatemachineAccess().getTransitionsTransitionParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruletransition();

            state._fsp--;

             after(grammarAccess.getStatemachineAccess().getTransitionsTransitionParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statemachine__TransitionsAssignment_5_3_1"


    // $ANTLR start "rule__State__NameAssignment_2"
    // InternalDsl.g:1193:1: rule__State__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__State__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1197:1: ( ( ruleEString ) )
            // InternalDsl.g:1198:2: ( ruleEString )
            {
            // InternalDsl.g:1198:2: ( ruleEString )
            // InternalDsl.g:1199:3: ruleEString
            {
             before(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getStateAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__State__NameAssignment_2"


    // $ANTLR start "rule__Transition__NameAssignment_1"
    // InternalDsl.g:1208:1: rule__Transition__NameAssignment_1 : ( ruleEString ) ;
    public final void rule__Transition__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1212:1: ( ( ruleEString ) )
            // InternalDsl.g:1213:2: ( ruleEString )
            {
            // InternalDsl.g:1213:2: ( ruleEString )
            // InternalDsl.g:1214:3: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getNameEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getNameEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__NameAssignment_1"


    // $ANTLR start "rule__Transition__SourceAssignment_4"
    // InternalDsl.g:1223:1: rule__Transition__SourceAssignment_4 : ( ( ruleEString ) ) ;
    public final void rule__Transition__SourceAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1227:1: ( ( ( ruleEString ) ) )
            // InternalDsl.g:1228:2: ( ( ruleEString ) )
            {
            // InternalDsl.g:1228:2: ( ( ruleEString ) )
            // InternalDsl.g:1229:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getSourceStateCrossReference_4_0()); 
            // InternalDsl.g:1230:3: ( ruleEString )
            // InternalDsl.g:1231:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getSourceStateEStringParserRuleCall_4_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getSourceStateEStringParserRuleCall_4_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getSourceStateCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__SourceAssignment_4"


    // $ANTLR start "rule__Transition__TargetAssignment_6"
    // InternalDsl.g:1242:1: rule__Transition__TargetAssignment_6 : ( ( ruleEString ) ) ;
    public final void rule__Transition__TargetAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1246:1: ( ( ( ruleEString ) ) )
            // InternalDsl.g:1247:2: ( ( ruleEString ) )
            {
            // InternalDsl.g:1247:2: ( ( ruleEString ) )
            // InternalDsl.g:1248:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getTargetStateCrossReference_6_0()); 
            // InternalDsl.g:1249:3: ( ruleEString )
            // InternalDsl.g:1250:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getTargetStateEStringParserRuleCall_6_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getTargetStateEStringParserRuleCall_6_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getTargetStateCrossReference_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__TargetAssignment_6"


    // $ANTLR start "rule__Transition__EventAssignment_7_1"
    // InternalDsl.g:1261:1: rule__Transition__EventAssignment_7_1 : ( ( ruleEString ) ) ;
    public final void rule__Transition__EventAssignment_7_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalDsl.g:1265:1: ( ( ( ruleEString ) ) )
            // InternalDsl.g:1266:2: ( ( ruleEString ) )
            {
            // InternalDsl.g:1266:2: ( ( ruleEString ) )
            // InternalDsl.g:1267:3: ( ruleEString )
            {
             before(grammarAccess.getTransitionAccess().getEventEventCrossReference_7_1_0()); 
            // InternalDsl.g:1268:3: ( ruleEString )
            // InternalDsl.g:1269:4: ruleEString
            {
             before(grammarAccess.getTransitionAccess().getEventEventEStringParserRuleCall_7_1_0_1()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getTransitionAccess().getEventEventEStringParserRuleCall_7_1_0_1()); 

            }

             after(grammarAccess.getTransitionAccess().getEventEventCrossReference_7_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Transition__EventAssignment_7_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000016000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x000000000000A000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000202000L});

}